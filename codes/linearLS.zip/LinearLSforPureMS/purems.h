#pragma once
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <limits.h>
#include <cmath>
#include <random>
#include <chrono>
#include <string.h>
#include <assert.h>
using namespace std;

typedef long long llong;

class PureMS{
private:
    //  all vars are indexed from 1;
    //  and clauses are from 0.
    int     nVars;
    int     nClauses;
    int     seed;
    int     cutoff_time;
    int     verb;
    llong   step;
    bool    lit_in_hClause_is_positive; //to remove var sense in the problem.
    llong   total_hard_lits;
    bool    binarySearch;
    bool    weightedSearch;
    chrono::steady_clock::time_point start;
    int     no_impr, alpha;
    llong   sum_vweight;
    int     cc_tabu_no_impr;
    int     bound_mod;
    int     rand_pick_mod;
    
    //info hard clauses;
    llong   hClasueWeight;
    int     nHClauses;
    int**   c_lits_hard;
    int*    c_lits_hard_size;
    int*    sat_num;                //sat literal num in clauses;
    int*    sat_var;                //a sat variable in cls
    llong*  cweight;                //weight of clauses
    


    //info about vars;
    int*    vweight;                // weight for variables
    int**   v_lits_hard;            // clauses number;
    int**   v_lits_hard_neighbor;   // neighbor for var in cls;
    int*    v_lits_hard_size;
     
    
    //soln. 
    //soln[var_idx] = 0(false) / 1(true)
    llong   cost;                 //the sum of unsat soft sat caluses weight
    llong   b_cost;               //best weight
    llong   unit_fixed_weight;      //weight fixed in up
    int*    soln;
    llong*  time_stamp;
    int*    b_soln;
    double  b_time;
    inline  void update_best_soln();


    //scores
    //vscore = sum(now uncovered w(e)) - ( +-node{v} uncovered w(e));
    // now      next    
    // 0    ->  1       : dscore>=0 
    // 1    ->  0       : dscore<=0 
    int*    dscore;
    int*    valid_score;


    //unsat clasues of hard clauses
    int*        unsat_in_hard;
    int         unsat_in_hard_size;
    int*        idx_in_unsat_hard;
    inline void sat_hard(int idx); //clause idx, pop
    inline void unsat_hard(int idx); //push


    //false var in soft
    int*        unsat_in_soft;
    int         unsat_in_soft_size;
    int*        idx_in_unsat_soft;
    inline void sat_soft(int idx); //var idx, push
    inline void unsat_soft(int idx);//pop


    //tabu to remove.
    int*        tabu_remove;    //0 can rm, 1 cannot rm.
    int*        tabu_list;      //store tabu_vars;
    int         tabu_list_size; 
    inline void tabu_add(int var);
    inline void clear_tabu();
    int         tabu_var;


    //smooth
    int         avg_weight;
    int         delta_total_weight;
    int         threshold;
    float       p_scale;


    //------------------------------------------
    //varify the soln.
    bool    varify();
    //allocate memory for data structures.
    void    allocate();
    //initialize all parameter.
    void    initPara();
    //get time 
    double  getRuntime();
    
    //var sense 1->0
    void    reset(int var);
    void    reset_binary(int var);
    void    reset_binary_weighted(int var);

    //var sense 0->1
    void    set(int var);  
    void    set_binary(int var);
    void    set_binary_weighted(int var);


    //if var set 0 or 1 do nothing to the hard clauses, set 0. 
    inline  void reset_redundent_var_nVars();
    inline  void reset_redundent_var_unsatSoft();
    inline  void reset_redundent_and_rmCand();
    //smooth weight
    void    update_clause_weight();
    void    forget_clause_weight();
    

    //pick var methods
    int        try_num;                 //BMS
    inline int pick_reset_var();
    inline int pick_reset_var_tabu();
    inline int pick_reset_var_dyn();
    inline int pick_reset_var_dscore();
    inline int pick_reset_var_dscore_tabu();
    inline int pick_reset_var_dscore_weighted();
    inline int pick_reset_var_dscore_tabu_weighted();
    inline int pick_reset_var_valid();


    int        try_pick;                //used in pick set var;
    inline int pick_set_var();
    inline int pick_set_var_cc();
    inline int pick_set_var_weighted(int remain_vweight);
    inline int pick_set_var_dscore();
    inline int pick_set_var_dscore_cc();
    inline int pick_set_var_dscore_weighted();
    inline int pick_set_var_dscore_cc_weighted();

    //---------------------------
    //heap used in the init_soln
    int*        fheap;
    int         fheap_sz;
    int*        idx_in_fheap;
    inline int  father(int i);
    inline int  leftson(int i);
    inline int  rightson(int i);
    inline void conduct_up(int idx);
    inline void conduct_down(int idx=0);
    void        init_fheap();
    void        set_and_remove(int var);
    //============================
public:
    //build from instance
    bool    build(string filename);
    //show the basic parameters of solver
    void    showParameters();
    //print soln following requirement.
    void    showSoln(bool needVarify);
    void    showSoln(string filename);
    void    setSeed(int s);
    void    setBoundMod(int bm);
    void    setCCTabu(int cct);
    void    setCutoff(int cutoff);
    void    setVerb(int verb);
    //the local search process, which need call build first.
    // bool    doLS_dyn();
    // bool    doLS_keep();
    bool    doLS();
    bool    doLS_binary();
    bool    doLS_binary_weighted();
    bool    doLS_unbinary();
    bool    doLS_unbinary_weighted();
    //initialize the solution by greey
    bool    initSoln_heap();
    bool    initSoln_rand();
    // bool    initSoln_rand_pickbest();
    void    freeMemory();
};




