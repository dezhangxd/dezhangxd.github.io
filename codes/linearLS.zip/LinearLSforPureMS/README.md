# NuPurems

Implementation for Linear Local Search.
The input instance should be ".wcnf" type
There are 4 vesion of linearLS, the default version is purems_mse.
purems_vc, _clq, _scp are 3 versions for better adaption of VC, CLQ and SCP.
Detailed result can be found in our paper of 'Pure MaxSAT'.

How to use our solver :

'./purems <ins> <seed> <cutoff_time> <verbosity>'

Note that, for parameter verbosity,
verbosity : 0, only print best solution
          : 1, print best solution and best assignment
          : 2, all information in the process and parameters