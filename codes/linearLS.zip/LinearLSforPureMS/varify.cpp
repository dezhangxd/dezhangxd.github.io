#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include <vector>
#include <string>

using namespace std;

vector<int> soln;
long weight;

void read_soln(string filename){
    ifstream fin(filename.c_str());
    soln.push_back(0);
    fin>>weight;
    int lit;
    while(fin>>lit){
        if(lit>0)
            soln.push_back(1);
        else
            soln.push_back(0);
    }
}

bool varify(string filename){
    long wt=0;
    long hClasueWeight=0;
    ifstream fin(filename.c_str());
    char line[1024];
    char tmpstr[10];
    long tmp_l;
    fin.getline(line,1024);
    while(line[0] != 'p') fin.getline(line,1024);
    sscanf(line,"%s %s %ld %ld %ld",tmpstr,tmpstr,&tmp_l,&tmp_l,&hClasueWeight);
    // cout<<hClasueWeight<<endl;

    long cls_wt;
    long cur_lit;
    while(fin>>cls_wt){
        // cout<<cls_wt<<" ";
        bool sat = false;
        fin>>cur_lit;
        while(cur_lit!=0){
            // cout<<cur_lit<<" ";
            int sense = ((cur_lit>0)?1:0);
            int var = abs(cur_lit);
            if(soln[var] == sense){
                sat = true;
                // break;
            }
            fin>>cur_lit;
        }
        // cout<<endl;
        if(cls_wt == hClasueWeight){
            //hard
            if(!sat){
                return false;
            }
        }else{
            //soft
            if(!sat){
                wt += cls_wt;
            }
        }
        
    }
    if(wt == weight) return true;
    else {
        cout<<"right weight = "<<wt<<endl;
        return false;
    }
}



int main(int argc, char** argv){
    string input_file(argv[1]);
    string output_file(argv[2]);
    read_soln(output_file);
    if(varify(input_file)==false){
        cout<<"wrong"<<endl;
    }else{
        cout<<"true"<<endl;
    }

    return 0;
}
