#include "purems.h"

void PureMS::allocate(){
    int var_mem = nVars + 2;
    int cls_mem = nClauses +1;
    c_lits_hard         = new int*[cls_mem];
    c_lits_hard_size    = new int[cls_mem];     memset(c_lits_hard_size,0,sizeof(int)*cls_mem);
    sat_num             = new int[cls_mem];     memset(sat_num,0,sizeof(int)*cls_mem);
    sat_var             = new int[cls_mem];     
    cweight             = new llong[cls_mem];   fill_n(cweight,cls_mem,1);
    vweight             = new int[var_mem];     memset(vweight,0,sizeof(int)*var_mem);
    v_lits_hard         = new int*[var_mem];
    v_lits_hard_neighbor= new int*[var_mem];
    v_lits_hard_size    = new int[var_mem];     memset(v_lits_hard_size,0,sizeof(int)*var_mem);
    soln                = new int[var_mem];     memset(soln,0,sizeof(int)*var_mem);
    b_soln              = new int[var_mem];     memset(b_soln,0,sizeof(int)*var_mem);
    time_stamp          = new llong[var_mem];   memset(time_stamp,0,sizeof(llong)*var_mem);
    dscore              = new int[var_mem];     memset(dscore,0,sizeof(int)*var_mem);
    valid_score         = new int[var_mem];     fill_n(valid_score,var_mem,INT_MAX);
    unsat_in_hard       = new int[cls_mem];
    unsat_in_soft       = new int[var_mem];
    idx_in_unsat_hard   = new int[cls_mem];
    idx_in_unsat_soft   = new int[var_mem];
    tabu_remove         = new int[var_mem];
    tabu_list           = new int[var_mem];
    fheap               = new int[var_mem];
    idx_in_fheap        = new int[var_mem];
}

void PureMS::freeMemory(){
    delete[] c_lits_hard_size;
    for(int i=0;i<nHClauses;++i)
        delete[] c_lits_hard[i];
    delete[] v_lits_hard_size;
    for(int i=1;i<=nVars;++i){
        delete[] v_lits_hard[i];
        delete[] v_lits_hard_neighbor[i];
    }
    delete[] v_lits_hard;
    delete[] v_lits_hard_neighbor;
    delete[] c_lits_hard;
    delete[] sat_num;
    delete[] sat_var;
    delete[] cweight;
    delete[] vweight;
    delete[] soln;
    delete[] b_soln;
    delete[] time_stamp;
    delete[] dscore;
    delete[] unsat_in_soft;
    delete[] unsat_in_hard;
    delete[] idx_in_unsat_soft;
    delete[] idx_in_unsat_hard;
    delete[] tabu_remove;
    delete[] tabu_list;
    delete[] fheap;
    delete[] idx_in_fheap;
}

void PureMS::initPara(){
    nHClauses = 0;
    b_cost = INT64_MAX;
    cost = 0;
    seed = 0;srand(seed);
    step = 1;
    start = chrono::steady_clock::now();
    avg_weight = 1;
    delta_total_weight = 0;
    p_scale = 0.3;
    threshold = (int)(0.5 * nVars);
    total_hard_lits = 0;
    unsat_in_soft_size = unsat_in_hard_size = tabu_list_size = 0;
    binarySearch = true ;
    weightedSearch = false;
    no_impr = 0;
    unit_fixed_weight = 0;
    alpha = 10000;
    sum_vweight = 0;
#ifdef CLQRE
    cc_tabu_no_impr = 100000;
    bound_mod = 10000;
    rand_pick_mod = 100;
#elif SCP
    cc_tabu_no_impr = 100000;
    bound_mod = 20000;
    rand_pick_mod = 200;
    // cc_tabu_no_impr = 100000;
    // bound_mod = 15000;
    // rand_pick_mod = 200;
#else
    cc_tabu_no_impr = 1000000;
    bound_mod = 10000;
    rand_pick_mod = 1000;
#endif
    try_num=50; //BMS in reset
    
#ifdef LARGE
    try_pick=2; //used in set
#else
    try_pick=1;
#endif
    
}


void PureMS::update_best_soln(){
    if(cost<b_cost){
        b_cost = cost;
        b_time = getRuntime();
        if(verb==0) return;
        for(int i=1;i<=nVars;++i) b_soln[i] = soln[i];
        if(verb<2) return;
#ifdef CLQRE
        cout<<"c (opt, time) = ("<<sum_vweight-(b_cost+unit_fixed_weight)<<", "<<b_time<<" )"<<endl;
#else
        cout<<"c (opt, time) = ("<<b_cost+unit_fixed_weight<<", "<<b_time<<" )"<<endl;
#endif
        
    }
}
void PureMS::showSoln(string filename){
    ofstream fout(filename);
    if(!fout){
        cout << "c something wrong with output_file." << endl;
        return;
    }
    fout<<b_cost+unit_fixed_weight<<endl;
    // fout<<"v ";
    if(lit_in_hClause_is_positive){
        for(int i=1;i<=nVars;++i){
            if(b_soln[i] == 0) fout<<"-";
            fout<<i<<" ";
        }fout<<endl;
    }else{
        for(int i=1;i<=nVars;++i){
            if(b_soln[i] == 1) fout<<"-";
            fout<<i<<" ";
        }fout<<endl;
    }
    fout.close();
    // cout<<"c Time : "<<b_time<<" s"<<endl;
}

void PureMS::showSoln(bool needVarify){
    if(needVarify && !varify()){
        cout << "c The soln is wrong." << endl;
        return;
    }
    #ifdef CLQRE
        cout<<"o "<<sum_vweight-(b_cost+unit_fixed_weight)<<endl;
    #else
        cout<<"o "<<b_cost+unit_fixed_weight<<endl;
        // cout<<"c "<<b_cost<<" "<<unit_fixed_weight<<endl;
    #endif
    if(verb>0){
        cout<<"v ";
        if(lit_in_hClause_is_positive){
            for(int i=1;i<=nVars;++i){
                if(b_soln[i] == 0) cout<<"-";
                cout<<i<<" ";
            }cout<<endl;
        }else{
            for(int i=1;i<=nVars;++i){
                if(b_soln[i] == 1) cout<<"-";
                cout<<i<<" ";
            }cout<<endl;
        }
    }
    // cout<<"c verb = "<<verb<<endl;
    cout<<"c Time : "<<b_time<<" s"<<endl;
}

char* readLong(char* pos,llong &i){
    i=0;
    bool sym = true;
    while (*pos < '0' || *pos > '9') {
		if(*pos == '-') sym = false;
        ++pos;
	}
	while (*pos >= '0' && *pos <= '9') {
		i = i * 10 +  *pos - '0';
		++pos;
	}
    if(!sym) i = -i;
    return pos;
}
char* readInt(char* pos,int &i){
    i=0;
    bool sym = true;
    while (*pos < '0' || *pos > '9') {
        if(*pos == '-') sym = false;
		++pos;
	}
	while (*pos >= '0' && *pos <= '9') {
		i = i * 10 +  *pos - '0';
		++pos;
	}
    if(!sym) i = -i;
    return pos;
}

bool PureMS::build(string filename){
    ifstream fin(filename);
    if(!fin){
        cout<<"c build wrong."<<endl;
        return false;
    }
    
    fin.seekg(0,fin.end);
    size_t file_len = fin.tellg();
    fin.seekg(0,fin.beg);
    char *data = new char[file_len+1];
    fin.read(data,file_len);
    fin.close();
    data[file_len] = '\0';
    char *pos = data;


    //skip comment
    while(*pos == 'c')while(*(pos++) != '\n');
    pos = readInt(pos,nVars);
    pos = readInt(pos,nClauses);
    pos = readLong(pos,hClasueWeight);
    allocate();initPara();
    
    int     cur_lit,cur_soft_lit;
    llong   sym;
    int*    a = new int[nVars];
    int     a_sz;
    int     readres; 
    for(int idx=nClauses;idx>0;--idx){
        pos = readLong(pos,sym);
        if(sym == hClasueWeight){
            a_sz = 0;
            pos = readInt(pos,cur_lit);
            while(cur_lit != 0){
                a[a_sz++] = abs(cur_lit);   
                pos = readInt(pos,cur_lit); 
            }
            if(a_sz == 1){
                soln[a[0]]=1;
                --nClauses;
                continue;
            }else if(a_sz > 2) binarySearch = false;
            c_lits_hard[nHClauses] = new int[a_sz+1];
            for(int i=0;i<a_sz;++i) c_lits_hard[nHClauses][i] = a[i];
            c_lits_hard_size[nHClauses] = a_sz;
            cweight[nHClauses++] = 1;
        }else{
            pos = readInt(pos,cur_soft_lit);
            sum_vweight += sym;
            if(sym != 1) weightedSearch = true;
            vweight[abs(cur_soft_lit)] += sym;
            pos = readInt(pos,a_sz);  
        }
    }
    lit_in_hClause_is_positive = (cur_soft_lit<0);
    //unit propagation()
    int idx=0,sz=nHClauses;
    for(int i=0;i<sz;++i){
        bool rm=false;
        for(int j=0;j<c_lits_hard_size[i];++j){
            if(soln[c_lits_hard[i][j]] == 1){
                rm = true;
                break;
            }
        }
        if(rm){
            nHClauses--;
            nClauses--;
        }else{
            if(idx != i ){
                c_lits_hard[idx] = c_lits_hard[i];
                c_lits_hard_size[idx] = c_lits_hard_size[i];
                cweight[idx] = cweight[i];
            }idx++;
        }
    }
    
    for(int i=1;i<=nVars;++i) if(soln[i] == 1) {unit_fixed_weight += vweight[i];}
    
    //build vars and neighbor
    for(int i=0;i<nHClauses;++i){
        for(int j=0;j<c_lits_hard_size[i];++j)
            v_lits_hard_size[c_lits_hard[i][j]]+=1;
        total_hard_lits += c_lits_hard_size[i];
    }
    for(int i=1;i<=nVars;++i) {
        v_lits_hard[i]          = new int[v_lits_hard_size[i]+1];
        v_lits_hard_neighbor[i] = new int[v_lits_hard_size[i]+1];
    }
    memset(v_lits_hard_size,0,sizeof(int)*(nVars+1));
    if(binarySearch){
        for(int i=0;i<nHClauses;++i){
            int v1 = c_lits_hard[i][0];
            int v2 = c_lits_hard[i][1];
            v_lits_hard[v1][v_lits_hard_size[v1]] = i;
            v_lits_hard[v2][v_lits_hard_size[v2]] = i;

            v_lits_hard_neighbor[v1][v_lits_hard_size[v1]++] = v2;
            v_lits_hard_neighbor[v2][v_lits_hard_size[v2]++] = v1;
            
        }
    }else{
        for(int i=0;i<nHClauses;++i){
            int cls_sz = c_lits_hard_size[i];
            for(int j=0;j<cls_sz;++j){
                int l = c_lits_hard[i][j];
                v_lits_hard[l][v_lits_hard_size[l]++] = i;
            }
        }
    }
    delete[] a;
    delete[] data;
    return true;
}


void PureMS::tabu_add(int var){
    tabu_list[tabu_list_size++] = var;
    tabu_remove[var] = 1;
}

void PureMS::clear_tabu(){
    for(int i=0;i<tabu_list_size;++i) tabu_remove[tabu_list[i]] = 0;
    tabu_list_size = 0;
}



void PureMS::sat_hard(int cls){
    int back_cls = unsat_in_hard[--unsat_in_hard_size];
    int idx_cls = idx_in_unsat_hard[cls];
    unsat_in_hard[idx_cls] = back_cls;
    idx_in_unsat_hard[back_cls] = idx_cls;
}

void PureMS::unsat_hard(int cls){
    idx_in_unsat_hard[cls] = unsat_in_hard_size;
    unsat_in_hard[unsat_in_hard_size++] = cls;
}

void PureMS::sat_soft(int var){
    int back_var = unsat_in_soft[--unsat_in_soft_size];
    int idx_var = idx_in_unsat_soft[var];
    unsat_in_soft[idx_var] = back_var;
    idx_in_unsat_soft[back_var] = idx_var;
}

void PureMS::unsat_soft(int var){
    idx_in_unsat_soft[var] = unsat_in_soft_size;
    unsat_in_soft[unsat_in_soft_size++] = var;
}

//set functions
//--------------------------------------------------------------
void PureMS::set(int var){
    if(soln[var] == 1) return;
    time_stamp[var] = step;
    dscore[var] = -dscore[var];
    soln[var] = 1;
    cost += vweight[var];
    unsat_soft(var);
    int v_sz = v_lits_hard_size[var];
    for(int i=0;i<v_sz;++i){
        int cls = v_lits_hard[var][i];
        ++sat_num[cls];
        if(sat_num[cls]==1){
            int c_sz = c_lits_hard_size[cls];
            for(int j=0;j<c_sz;++j){
                int v = c_lits_hard[cls][j];
                if(v != var) dscore[v] -= cweight[cls];
            }
            sat_hard(cls); 
            sat_var[cls] = var;
        }else if(sat_num[cls]==2){
            dscore[sat_var[cls]] += cweight[cls];
        }
    }
}

void PureMS::set_binary(int var){
    time_stamp[var] = step;
    dscore[var] = -dscore[var];
    // valid_score[var] = -1;
    soln[var] = 1;
    unsat_soft(var);
    int sz = v_lits_hard_size[var];
    for(int i=0;i<sz;++i){
        int cls = v_lits_hard[var][i];
        int neighbor = v_lits_hard_neighbor[var][i];
        if(soln[neighbor] == 0){
            dscore[neighbor] --;//-= cweight[cls];
            sat_hard(cls);
            // valid_score[var] ++;
        }else{
            dscore[neighbor] ++;//+= cweight[cls];
            // valid_score[neighbor] --;
        }
    }
}

void PureMS::set_binary_weighted(int var){
    time_stamp[var] = step;
    dscore[var] = -dscore[var];
    cost += vweight[var];
    // valid_score[var] = -1;
    soln[var] = 1;
    unsat_soft(var);
    int sz = v_lits_hard_size[var];
    for(int i=0;i<sz;++i){
        int cls = v_lits_hard[var][i];
        int neighbor = v_lits_hard_neighbor[var][i];
        if(soln[neighbor] == 0){
            dscore[neighbor] -= cweight[cls];
            sat_hard(cls);
            // valid_score[var] ++;
        }else{
            dscore[neighbor] += cweight[cls];
            // valid_score[neighbor] --;
        }
    }
}


//used in heap
void PureMS::set_and_remove(int var){
    if(soln[var] == 1) return;
    dscore[var] = -dscore[var];
    soln[var] = 1;
    cost += vweight[var];
    unsat_soft(var);
    for(int i=0;i<v_lits_hard_size[var];++i){
        int cls = v_lits_hard[var][i];
        ++sat_num[cls];
        if(sat_num[cls]==1){
            for(int j=0;j<c_lits_hard_size[cls];++j){
                int v = c_lits_hard[cls][j];
                if(v != var) {
                    dscore[v] -= cweight[cls];
                    conduct_down(idx_in_fheap[v]);
                }
            }
            sat_hard(cls); 
            sat_var[cls] = var;
        }else if(sat_num[cls]==2){
            dscore[sat_var[cls]] += cweight[cls];
            conduct_up(idx_in_fheap[sat_var[cls]]);
        }
    }
    int back_var = fheap[--fheap_sz];
    idx_in_fheap[back_var] = 0;
    fheap[0] = back_var;
    conduct_down();
}


//reset functions
//---------------------------------------------------------
void PureMS::reset(int var){
    if(soln[var] == 0) return;
    time_stamp[var] = step;
    dscore[var] = -dscore[var];
    soln[var] = 0;
    cost -= vweight[var];
    sat_soft(var);
    int v_sz = v_lits_hard_size[var];
    for(int i=0;i<v_sz;++i){
        int cls = v_lits_hard[var][i];
        --sat_num[cls];
        if(sat_num[cls] == 0){
            for(int j=0;j<c_lits_hard_size[cls];++j){
                int v = c_lits_hard[cls][j];
                if(v != var) {dscore[v] += cweight[cls]; }
            }
            unsat_hard(cls);
        }else if(sat_num[cls]==1){
            for(int j=0;j<c_lits_hard_size[cls];++j){
                int v = c_lits_hard[cls][j];
                if(soln[v]==1){
                    dscore[v] -= cweight[cls];
                    sat_var[cls] = v;
                    break;
                }
            }
        }
    }
}


void PureMS::reset_binary(int var){
    time_stamp[var] = step;
    dscore[var] = -dscore[var];
    // valid_score[var] = INT_MAX;
    soln[var] = 0;
    sat_soft(var);
    int sz = v_lits_hard_size[var];
    for(int i=0;i<sz;++i){
        int cls = v_lits_hard[var][i];
        int neighbor = v_lits_hard_neighbor[var][i]; 
        if(soln[neighbor] == 0){
            dscore[neighbor] ++;//= cweight[cls];
            unsat_hard(cls);
            sat_var[cls] = var;
        }else{
            dscore[neighbor] --;//= cweight[cls];
            // valid_score[neighbor] ++;
        }
    }
}


void PureMS::reset_binary_weighted(int var){
    time_stamp[var] = step;
    dscore[var] = -dscore[var];
    cost -= vweight[var];
    // valid_score[var] = INT_MAX;
    soln[var] = 0;
    sat_soft(var);
    int sz = v_lits_hard_size[var];
    for(int i=0;i<sz;++i){
        int cls = v_lits_hard[var][i];
        int neighbor = v_lits_hard_neighbor[var][i]; 
        if(soln[neighbor] == 0){
            dscore[neighbor] = cweight[cls];
            unsat_hard(cls);
            sat_var[cls] = var;
        }else{
            dscore[neighbor] = cweight[cls];
            // valid_score[neighbor] ++;
        }
    }
}

//initialization
//===============================================================



//a heap used to give an init soln
//for cut_propogation
int PureMS::father(int i){return (i-1)/2; }
int PureMS::leftson(int i){return i*2+1;}
int PureMS::rightson(int i){return i*2+2;}

void PureMS::conduct_up(int idx){
	while(idx>0){
		int f = father(idx);
		if((float)dscore[fheap[idx]]/vweight[fheap[idx]] > (float)dscore[fheap[f]]/vweight[fheap[f]]){
			swap(fheap[idx],fheap[f]);
            swap(idx_in_fheap[fheap[idx]],idx_in_fheap[fheap[f]]);
			idx = f;
		}else return;
	}
}

void PureMS::conduct_down(int idx){
	int left=leftson(idx);
	int right=rightson(idx);
	while(left<fheap_sz){
		int maxSon=left;
		if(right<fheap_sz && (float)dscore[fheap[left]]/vweight[fheap[left]] < (float)dscore[fheap[right]]/vweight[fheap[right]] ) 
            maxSon=right;
		if((float)dscore[fheap[maxSon]]/vweight[fheap[maxSon]] > (float)dscore[fheap[idx]]/vweight[fheap[idx]]){
            swap(fheap[maxSon],fheap[idx]);
            swap(idx_in_fheap[fheap[idx]],idx_in_fheap[fheap[maxSon]]);
        }
		else return;
		idx = maxSon;
		left=leftson(idx);
		right=rightson(idx);
	}
}

void PureMS::init_fheap(){
    fheap_sz = 0;
    for(int v=1;v<=nVars;++v){
        if(soln[v]==1) continue;
        fheap[fheap_sz] = v;
        idx_in_fheap[v] = fheap_sz;
        conduct_up(fheap_sz++);
    }
}

bool PureMS::initSoln_heap(){
    for(int i=1;i<=nVars;++i) dscore[i] = v_lits_hard_size[i];
    //init score
    init_fheap();
    //all clauses in hard are unsat
    for(int i=0;i<nHClauses;++i) unsat_hard(i);
      
    //from all 0 soln to build. 
    while(unsat_in_hard_size>0){
        int wait_reset_var = fheap[0];
        set_and_remove(wait_reset_var);
    }
    update_best_soln();
    return true;
}

bool PureMS::initSoln_rand(){
    if(weightedSearch){
        for(int idx=0;idx<nHClauses;++idx){
            bool unsat = true;
            int wait_set_var = c_lits_hard[idx][0];
            if(soln[wait_set_var] == 1) continue;
            int cls_sz = c_lits_hard_size[idx];
            for(int i=1;i<cls_sz;++i){
                int tmp_var = c_lits_hard[idx][i];
                if(soln[tmp_var] == 1){unsat = false;break;}
                if((float) v_lits_hard_size[tmp_var]/vweight[tmp_var] >= (float)v_lits_hard_size[wait_set_var]/vweight[wait_set_var])
                    wait_set_var = tmp_var;
            }
            if(unsat){
                soln[wait_set_var] = 1;
                cost += vweight[wait_set_var];
                unsat_soft(wait_set_var);
            }
        }
    }else{
        for(int idx=0;idx<nHClauses;++idx){
            bool unsat = true;
            int wait_set_var = c_lits_hard[idx][0];
            if(soln[wait_set_var] == 1) continue;
            int cls_sz = c_lits_hard_size[idx];
            for(int i=1;i<cls_sz;++i){
                int tmp_var = c_lits_hard[idx][i];
                if(soln[tmp_var] == 1){unsat = false;break;}
                if(v_lits_hard_size[tmp_var]>=v_lits_hard_size[wait_set_var])
                    wait_set_var = tmp_var;
            }
            if(unsat){
                soln[wait_set_var] = 1;
                cost += 1;
                unsat_soft(wait_set_var);
            }
        }
    }
    //init sat_num, dscore, sat_var;
    for(int i=0;i<unsat_in_soft_size;++i) {
        int var = unsat_in_soft[i];
        // valid_score[var] = -vweight[var];
    }
    for(int cls=0;cls<nHClauses;++cls){
        for(int j=0;j<c_lits_hard_size[cls];++j){
            int var = c_lits_hard[cls][j];
            if(soln[var]==1) {
                sat_num[cls]++;
                sat_var[cls] = var;
            }
        }
        if(sat_num[cls]==1) {
            int s_var = sat_var[cls];
            dscore[s_var] -= vweight[s_var];
            int min_vw = INT_MAX;
            for(int j=0;j<c_lits_hard_size[cls];++j){
                int var = c_lits_hard[cls][j];
                if(soln[var] == 0) min_vw = min(min_vw,vweight[var]);
            }
            // valid_score[s_var] += min_vw;
        }
    }
    
    return true;
}


void PureMS::forget_clause_weight(){
    int sum_weight = 0;
    for(int v=1;v<=nVars;++v) dscore[v] = 0;
    for(int cls=0;cls<nHClauses;++cls){
        cweight[cls] *= p_scale;
        if(sat_num[cls] == 0)
            for(int j=0;j<c_lits_hard_size[cls];++j) dscore[c_lits_hard[cls][j]] += cweight[cls];
        else if(sat_num[cls] == 1)
            dscore[sat_var[cls]] -= cweight[cls];
    }
    avg_weight = sum_weight/nHClauses;
}

void PureMS::update_clause_weight(){
    for(int i=0;i<unsat_in_hard_size;++i){
        int cls = unsat_in_hard[i];
        cweight[cls] += 1;
        int cls_sz = c_lits_hard_size[cls];
        for(int j=0;j<cls_sz;++j) dscore[c_lits_hard[cls][j]] += 1;
    }
    delta_total_weight += unsat_in_hard_size;
    if(delta_total_weight >= nHClauses){
        avg_weight += 1;
        delta_total_weight -= nHClauses;
    }
    if(avg_weight >= threshold) 
        forget_clause_weight();
}


void PureMS::reset_redundent_var_unsatSoft(){
    for(int i=0;i<unsat_in_soft_size;++i){
        int var = unsat_in_soft[i];
        if(dscore[var]==0)
            reset(var);
    }
}

void PureMS::reset_redundent_var_nVars(){
     for(int i=1;i<=nVars;++i){
        if(soln[i]==1 && dscore[i]==0){
            reset_binary(i);
        }
    }
}


//-----------------------------------
int PureMS::pick_reset_var(){
    if(rand()%rand_pick_mod<2 || unsat_in_soft_size == tabu_list_size) return unsat_in_soft[rand()%unsat_in_soft_size];
    int i = 0;
    while(tabu_remove[unsat_in_soft[i]]==1) i++;
    int best_unsat_var = unsat_in_soft[i];
    float best_avg_weight = (float)dscore[best_unsat_var]/vweight[best_unsat_var];
    for(;i<unsat_in_soft_size;++i){
        int v = unsat_in_soft[i];
        // if(tabu_remove[v]==0){
            float v_avg = (float)dscore[v]/vweight[v];
            if((v_avg > best_avg_weight) \
                || (v_avg == best_avg_weight && time_stamp[v] < time_stamp[best_unsat_var]) ){
                best_unsat_var = v;
                best_avg_weight = v_avg;
            }
        // }
    }
    return best_unsat_var;
}

int PureMS::pick_reset_var_tabu(){
    if(rand()%rand_pick_mod<2 || unsat_in_soft_size == tabu_list_size) return unsat_in_soft[rand()%unsat_in_soft_size];
    int i = 0;
    while(tabu_remove[unsat_in_soft[i]]==1) i++;
    int best_unsat_var = unsat_in_soft[i];
    float best_avg_weight = (float)dscore[best_unsat_var]/vweight[best_unsat_var];
    for(;i<unsat_in_soft_size;++i){
        int v = unsat_in_soft[i];
        if(tabu_remove[v]==0){
            float v_avg = (float)dscore[v]/vweight[v];
            if((v_avg > best_avg_weight) \
                || (v_avg == best_avg_weight && time_stamp[v] < time_stamp[best_unsat_var]) ){
                best_unsat_var = v;
                best_avg_weight = v_avg;
            }
        }
    }
    return best_unsat_var;
}


int PureMS::pick_reset_var_dscore(){
    int best_unsat_var = unsat_in_soft[rand()%unsat_in_soft_size];
    if(rand()%rand_pick_mod<1) return best_unsat_var;
    for(int i=1;i<try_num;++i){
        int v = unsat_in_soft[rand()%unsat_in_soft_size];
        if(dscore[v] < dscore[best_unsat_var]){
            continue;
        }else if(dscore[v] > dscore[best_unsat_var]){
            best_unsat_var = v;
        }else if(time_stamp[v]<time_stamp[best_unsat_var]){
            best_unsat_var = v;
        }
    }
    return best_unsat_var;
}
int PureMS::pick_reset_var_dscore_tabu(){
    int best_unsat_var = unsat_in_soft[rand()%unsat_in_soft_size];
    if(rand()%rand_pick_mod<1 || unsat_in_soft_size == tabu_list_size) return best_unsat_var;
    while(tabu_remove[best_unsat_var]==1) {best_unsat_var = unsat_in_soft[rand()%unsat_in_soft_size];}
    for(int i=1;i<try_num;++i){
        int v = unsat_in_soft[rand()%unsat_in_soft_size];
        if(dscore[v] < dscore[best_unsat_var] || tabu_remove[v]==1){
            continue;
        }else if(dscore[v] > dscore[best_unsat_var]){
            best_unsat_var = v;
        }else if(time_stamp[v]<time_stamp[best_unsat_var]){
            best_unsat_var = v;
        }
    }
    return best_unsat_var;
}

int PureMS::pick_reset_var_dscore_weighted(){
    int best_unsat_var = unsat_in_soft[rand()%unsat_in_soft_size];
    if(rand()%rand_pick_mod<1) return best_unsat_var;
    float avg_b = (float)dscore[best_unsat_var]/vweight[best_unsat_var];
    for(int i=1;i<try_num;++i){
        int v = unsat_in_soft[rand()%unsat_in_soft_size];
        float avg_v = (float)dscore[v]/vweight[v];
        if(avg_v < avg_b){
            continue;
        }else if(avg_v > avg_b){
            best_unsat_var = v;
            avg_b = avg_v;
        }else if(time_stamp[v]<time_stamp[best_unsat_var]){
            best_unsat_var = v;
            avg_b = avg_v;
        }
    }
    return best_unsat_var;
}

int PureMS::pick_reset_var_dscore_tabu_weighted(){
    int best_unsat_var = unsat_in_soft[rand()%unsat_in_soft_size];
    if(rand()%rand_pick_mod<1) return best_unsat_var;
    while(tabu_remove[best_unsat_var]==1 || unsat_in_soft_size == tabu_list_size) {best_unsat_var = unsat_in_soft[rand()%unsat_in_soft_size];}
    float avg_b = (float)dscore[best_unsat_var]/vweight[best_unsat_var];
    for(int i=1;i<try_num;++i){
        int v = unsat_in_soft[rand()%unsat_in_soft_size];
        float avg_v = (float)dscore[v]/vweight[v];
        if(avg_v < avg_b || tabu_remove[v]==1){
            continue;
        }else if(avg_v > avg_b){
            best_unsat_var = v;
            avg_b = avg_v;
        }else if(time_stamp[v]<time_stamp[best_unsat_var]){
            best_unsat_var = v;
            avg_b = avg_v;
        }
    }
    return best_unsat_var;
}


// int PureMS::pick_reset_var_valid(){
//     int best_unsat_var = unsat_in_soft[0];
//     for(int i=1;i<unsat_in_soft_size;++i){
//         int v = unsat_in_soft[i];
//         if(valid_score[v] < valid_score[best_unsat_var]){
//             continue;
//         }else if(valid_score[v] > valid_score[best_unsat_var]){
//             best_unsat_var = v;
//         }else if(time_stamp[v]<time_stamp[best_unsat_var]){
//             best_unsat_var = v;
//         }
//     }
//     return best_unsat_var;
// }


//--------------------------------------

int PureMS::pick_set_var(){
    int cls = unsat_in_hard[rand() % unsat_in_hard_size];
    int cls_sz = c_lits_hard_size[cls];
    if(rand()%rand_pick_mod<2){return c_lits_hard[cls][rand()%cls_sz];}
    int i = 0;
    int best_sat_var = c_lits_hard[cls][i++];
    if(best_sat_var == sat_var[cls]) best_sat_var = c_lits_hard[cls][i++];
    float avg_b = (float)dscore[best_sat_var]/vweight[best_sat_var];
    for(;i<cls_sz;++i){
        int v = c_lits_hard[cls][i];
        float avg_v = (float)dscore[v]/vweight[v];
        if(avg_v < avg_b){
            continue;
        }else if(avg_v > avg_b){
            best_sat_var = v;
            avg_b = avg_v;
        }else if(time_stamp[v] < time_stamp[best_sat_var]){
            best_sat_var = v;
            avg_b = avg_v;
        }
    }
    return best_sat_var;
}

int PureMS::pick_set_var_cc(){
    int cls = unsat_in_hard[rand() % unsat_in_hard_size];
    int cls_sz = c_lits_hard_size[cls];
    if(rand()%rand_pick_mod<2){return c_lits_hard[cls][rand()%cls_sz];}
    int i = 0;
    int best_sat_var = c_lits_hard[cls][i++];
    if(best_sat_var == sat_var[cls]) best_sat_var = c_lits_hard[cls][i++];
    float avg_b = (float)dscore[best_sat_var]/vweight[best_sat_var];
    for(;i<cls_sz;++i){
        int v = c_lits_hard[cls][i];
        float avg_v = (float)dscore[v]/vweight[v];
        if(avg_v < avg_b || sat_var[cls]==v){
            continue;
        }else if(avg_v > avg_b){
            best_sat_var = v;
            avg_b = avg_v;
        }else if(time_stamp[v] < time_stamp[best_sat_var]){
            best_sat_var = v;
            avg_b = avg_v;
        }
    }
    return best_sat_var;
}

int PureMS::pick_set_var_weighted(int remain_vweight){
    int best_sat_var = -1;
    float avg_b;
    int remain_pick_cls_time = 10;
    int cls,cls_sz;
    while(best_sat_var==-1 && remain_pick_cls_time-->0){
        cls = unsat_in_hard[rand() % unsat_in_hard_size];
        cls_sz = c_lits_hard_size[cls];
        for(int i=0;i<cls_sz;++i){
            int v = c_lits_hard[cls][i];
            float avg_v=(float)dscore[v]/vweight[v];
            if(vweight[v] < remain_vweight){
                if(best_sat_var == -1){
                    best_sat_var = v;
                    avg_b = avg_v;
                }else{
                    if(avg_v < avg_b){
                        continue;
                    }else if(avg_v > avg_b){
                        best_sat_var = v;
                        avg_b = avg_v;
                    }else if(time_stamp[v] < time_stamp[best_sat_var]){
                        best_sat_var = v;
                        avg_b = avg_v;
                    }
                }
            }
        }
    }
    while(remain_pick_cls_time-->0){
        cls = unsat_in_hard[rand() % unsat_in_hard_size];
        cls_sz = c_lits_hard_size[cls];
        for(int i=0;i<cls_sz;++i){
            int v = c_lits_hard[cls][i];
            float avg_v=(float)dscore[v]/vweight[v];
            if(vweight[v] < remain_vweight){
                if(avg_v < avg_b){
                    continue;
                }else if(avg_v > avg_b){
                    best_sat_var = v;
                    avg_b = avg_v;
                }else if(time_stamp[v] < time_stamp[best_sat_var]){
                    best_sat_var = v;
                    avg_b = avg_v;
                }
            }
        }
    }
    return best_sat_var;
}


int PureMS::pick_set_var_dscore(){
    int cls = unsat_in_hard[rand() % unsat_in_hard_size];
    int i = 0;
    int best_sat_var = c_lits_hard[cls][i++];
    int cls_sz = c_lits_hard_size[cls];
    for(;i<cls_sz;++i){
        int v = c_lits_hard[cls][i];
        if(dscore[v] < dscore[best_sat_var]){
            continue;
        }else if(dscore[v] > dscore[best_sat_var]){
            best_sat_var = v;
        }else if(time_stamp[v] < time_stamp[best_sat_var]){
            best_sat_var = v;
        }
    }
    for(int try_num = 1;try_num<try_pick;++try_num){
        cls = unsat_in_hard[rand() % unsat_in_hard_size];
        cls_sz = c_lits_hard_size[cls];
        for(i = 0;i<cls_sz;++i){
            int v = c_lits_hard[cls][i];
            if(dscore[v] < dscore[best_sat_var]){
                continue;
            }else if(dscore[v] > dscore[best_sat_var]){
                best_sat_var = v;
            }else if(time_stamp[v] < time_stamp[best_sat_var]){
                best_sat_var = v;
            }
        }
    }
    return best_sat_var;
}


int PureMS::pick_set_var_dscore_cc(){
    int cls = unsat_in_hard[rand() % unsat_in_hard_size];
    int i = 0;
    int best_sat_var = c_lits_hard[cls][i++];
    int cls_sz = c_lits_hard_size[cls];
    if(best_sat_var == sat_var[cls]) best_sat_var = c_lits_hard[cls][i++];
    for(;i<cls_sz;++i){
        int v = c_lits_hard[cls][i];
        if(dscore[v] < dscore[best_sat_var]){
            continue;
        }else if(dscore[v] > dscore[best_sat_var]){
            best_sat_var = v;
        }else if(time_stamp[v] < time_stamp[best_sat_var]){
            best_sat_var = v;
        }
    }
    for(int try_num = 1;try_num<try_pick;++try_num){
        cls = unsat_in_hard[rand() % unsat_in_hard_size];
        cls_sz = c_lits_hard_size[cls];
        for(i = 0;i<cls_sz;++i){
            int v = c_lits_hard[cls][i];
            if(dscore[v] < dscore[best_sat_var] || sat_var[cls]==v){
                continue;
            }else if(dscore[v] > dscore[best_sat_var]){
                best_sat_var = v;
            }else if(time_stamp[v] < time_stamp[best_sat_var]){
                best_sat_var = v;
            }
        }
    }
    return best_sat_var;
}

int PureMS::pick_set_var_dscore_weighted(){
    int cls = unsat_in_hard[rand() % unsat_in_hard_size];
    int i = 0;
    int best_sat_var = c_lits_hard[cls][i++];
    float avg_b = (float)dscore[best_sat_var]/vweight[best_sat_var];
    int cls_sz = c_lits_hard_size[cls];
    for(;i<cls_sz;++i){
        int v = c_lits_hard[cls][i];
        float avg_v = (float)dscore[v]/vweight[v];
        if(avg_v < avg_b){
            continue;
        }else if(avg_v > avg_b){
            best_sat_var = v;
            avg_b = avg_v;
        }else if(time_stamp[v] < time_stamp[best_sat_var]){
            best_sat_var = v;
            avg_b = avg_v;
        }
    }
    for(int try_num = 1;try_num<try_pick;++try_num){
        cls = unsat_in_hard[rand() % unsat_in_hard_size];
        cls_sz = c_lits_hard_size[cls];
        for(i = 0;i<cls_sz;++i){
            int v = c_lits_hard[cls][i];
            float avg_v = (float)dscore[v]/vweight[v];
            if(avg_v < avg_b){
                continue;
            }else if(avg_v > avg_b){
                best_sat_var = v;
                avg_b = avg_v;
            }else if(time_stamp[v] < time_stamp[best_sat_var]){
                best_sat_var = v;
                avg_b = avg_v;
            }
        }
    }
    return best_sat_var;
}
int PureMS::pick_set_var_dscore_cc_weighted(){
    int cls = unsat_in_hard[rand() % unsat_in_hard_size];
    int i = 0;
    int best_sat_var = c_lits_hard[cls][i++];
    int cls_sz = c_lits_hard_size[cls];
    if(best_sat_var == sat_var[cls]) best_sat_var = c_lits_hard[cls][i++];
    float avg_b = (float)dscore[best_sat_var]/vweight[best_sat_var];
    for(;i<cls_sz;++i){
        int v = c_lits_hard[cls][i];
        float avg_v = (float)dscore[v]/vweight[v];
        if(avg_v < avg_b || sat_var[cls]==v){
            continue;
        }else if(avg_v > avg_b){
            best_sat_var = v;
            avg_b = avg_v;
        }else if(time_stamp[v] < time_stamp[best_sat_var]){
            best_sat_var = v;
            avg_b = avg_v;
        }
    }
    for(int try_num = 1;try_num<try_pick;++try_num){
        cls = unsat_in_hard[rand() % unsat_in_hard_size];
        cls_sz = c_lits_hard_size[cls];
        for(i = 0;i<cls_sz;++i){
            int v = c_lits_hard[cls][i];
            float avg_v = (float)dscore[v]/vweight[v];
            if(avg_v < avg_b || sat_var[cls]==v){
                continue;
            }else if(avg_v > avg_b){
                best_sat_var = v;
                avg_b = avg_v;
            }else if(time_stamp[v] < time_stamp[best_sat_var]){
                best_sat_var = v;
                avg_b = avg_v;
            }
        }
    }
    return best_sat_var;
}


//-----------------------------------------------------------------
bool PureMS::doLS(){
    bool res;
    if(binarySearch){
        if(weightedSearch)
            res = doLS_binary_weighted();
        else
            res = doLS_binary();
    }else{
        res = doLS_unbinary_weighted();
    }
    return res;
}

#ifdef SCP
bool PureMS::doLS_unbinary_weighted(){
    int wait_reset_var,wait_set_var;
    bool cc_tabu = false;
    while(true){
        if(unsat_in_hard_size==0){
            reset_redundent_var_unsatSoft();
            update_best_soln();
            no_impr=0;
        }
        if(no_impr > cc_tabu_no_impr) {no_impr=0;cc_tabu = !cc_tabu;}
        int sum_avg = 0;
        int reset_real_num = 0;
        int reset_up_bound = 1 + no_impr/bound_mod;
        while(sum_avg < (float)1*total_hard_lits / nVars && unsat_in_soft_size>0 && reset_real_num < reset_up_bound){
            if(cc_tabu)
                wait_reset_var = pick_reset_var_tabu();
            else
                wait_reset_var = pick_reset_var();
            reset(wait_reset_var);
            sum_avg += v_lits_hard_size[wait_reset_var];
            reset_real_num++;
        }
        int upbound_cost = b_cost-1;
        clear_tabu();
        while(unsat_in_hard_size > 0){
            if(cc_tabu)
                wait_set_var = pick_set_var_cc();
            else
                wait_set_var = pick_set_var();
            if(cost + vweight[wait_set_var] > upbound_cost) break;
            set(wait_set_var);
            tabu_add(wait_set_var);
            update_clause_weight();
        }
        
        ++step;
        if(step%1000 == 0 && (int)getRuntime()>=cutoff_time){
            return true;
        }
        no_impr += reset_real_num;
    }
    return true;
}
#else
bool PureMS::doLS_unbinary_weighted(){
    int wait_reset_var,wait_set_var;
    bool cc_tabu = true;
    while(true){
        if(unsat_in_hard_size==0){
            reset_redundent_var_unsatSoft();
            update_best_soln();
            // showSoln(false);
            no_impr=0;
        }
        if(no_impr > cc_tabu_no_impr) {no_impr=0;}
        int sum_avg = 0;
        int reset_real_num = 0;
        int reset_up_bound = 1 + no_impr/bound_mod;
        while(sum_avg < (float)2*total_hard_lits / nVars && unsat_in_soft_size>0 && reset_real_num < reset_up_bound){
            wait_reset_var = pick_reset_var();
            reset(wait_reset_var);
            sum_avg += v_lits_hard_size[wait_reset_var];
            reset_real_num++;
        }
        int upbound_cost = b_cost-1;
        clear_tabu();
        while(unsat_in_hard_size > 0){
            wait_set_var = pick_set_var();
            if(cost + vweight[wait_set_var] > upbound_cost) break;
            set(wait_set_var);
            tabu_add(wait_set_var);
        }
        update_clause_weight();
        ++step;
        if(step%1000 == 0 && (int)getRuntime()>=cutoff_time){
            return true;
        }
        no_impr += reset_real_num;
    }
    return true;
}
#endif

bool PureMS::doLS_unbinary(){
    cout<<"c this function should not be used\n";
    return false;
}


bool PureMS::doLS_binary_weighted(){
    int wait_reset_var,wait_set_var;
    bool cc_tabu = false;
    while(true){
        if(unsat_in_hard_size==0){
            reset_redundent_var_nVars();
            update_best_soln();
            no_impr = 0;
        }
        if(no_impr > cc_tabu_no_impr) {no_impr=0;}
        int sum_avg = 0;
        int reset_real_num = 0;
        int reset_up_bound = 1+no_impr/bound_mod;
        while(sum_avg < (float)2*total_hard_lits / nVars && unsat_in_soft_size>0 && reset_real_num < reset_up_bound){
            wait_reset_var = pick_reset_var_dscore_weighted();
            reset_binary_weighted(wait_reset_var);
            sum_avg += v_lits_hard_size[wait_reset_var];
            reset_real_num++;
        }
        while(unsat_in_hard_size > 0){
            wait_set_var = pick_set_var_dscore_weighted();
            if(vweight[wait_set_var] >= b_cost-cost){
                wait_set_var = pick_set_var_weighted(b_cost-cost);
                if(wait_set_var == -1) break;
            }
            set_binary_weighted(wait_set_var);
        }
        ++step;
        if(step%1000 == 0 && (int)getRuntime()>=cutoff_time){
            return true;
        }
        no_impr += reset_real_num;
    }
    

    return true;
}

//binary unweighted
#ifdef CLQRE
bool PureMS::doLS_binary(){
    int wait_reset_var,wait_set_var;
    bool cc_tabu = false;
    while(true){
        if(unsat_in_hard_size==0){
            reset_redundent_var_nVars();
            cost = unsat_in_soft_size;
            update_best_soln();
            no_impr = 0;
        }
        if(no_impr > cc_tabu_no_impr) {cc_tabu = !cc_tabu;no_impr=0;}
        int sum_avg = 0;
        int reset_up_bound = 1 + no_impr/bound_mod;
        int reset_real_num = 0;
        while(sum_avg < (float)1*total_hard_lits / nVars && unsat_in_soft_size >= b_cost-reset_up_bound){
            if(cc_tabu)
                wait_reset_var = pick_reset_var_dscore_tabu();
            else
                wait_reset_var = pick_reset_var_dscore();
            reset_binary(wait_reset_var);
            sum_avg += v_lits_hard_size[wait_reset_var];
            reset_real_num++;
        }
        if(cc_tabu) clear_tabu();
        while(unsat_in_hard_size>0 && unsat_in_soft_size < b_cost-1){
            if(cc_tabu){
                wait_set_var = pick_set_var_dscore_cc();
                tabu_add(wait_set_var);
            }else{
                wait_set_var = pick_set_var_dscore();
            }
            set_binary(wait_set_var); 
        }
        ++step;
        if(step%1000 == 0 && (int)getRuntime()>=cutoff_time){
            return true;
        }
        no_impr++;//=reset_real_num;
    }
    return true;
}
#else
bool PureMS::doLS_binary(){
    int wait_reset_var,wait_set_var;
    bool cc_tabu = true;
    while(true){
        if(unsat_in_hard_size==0){
            reset_redundent_var_nVars();
            cost = unsat_in_soft_size;
            update_best_soln();
            no_impr = 0;
        }
        if(no_impr > cc_tabu_no_impr) {cc_tabu = !cc_tabu;no_impr=0;}
        int sum_avg = 0;
        int reset_up_bound = 1 + no_impr/bound_mod;
        int reset_real_num = 0;
        while(sum_avg < (float)2*total_hard_lits / nVars && unsat_in_soft_size >= b_cost-reset_up_bound){
            if(cc_tabu)
                wait_reset_var = pick_reset_var_dscore_tabu();
            else
                wait_reset_var = pick_reset_var_dscore();
            reset_binary(wait_reset_var);
            sum_avg += v_lits_hard_size[wait_reset_var];
            reset_real_num++;
        }
        if(cc_tabu) clear_tabu();
        while(unsat_in_hard_size>0 && unsat_in_soft_size < b_cost-1){
            if(cc_tabu){
                wait_set_var = pick_set_var_dscore_cc();
                tabu_add(wait_set_var);
            }else{
                wait_set_var = pick_set_var_dscore();
            }
            set_binary(wait_set_var); 
        }
        ++step;
        if(step%1000 == 0 && (int)getRuntime()>=cutoff_time){
            return true;
        }
        no_impr++;//=reset_real_num;
    }
    return true;
}
#endif
//==============================================================

double PureMS::getRuntime(){
    chrono::steady_clock::time_point now = chrono::steady_clock::now();
    chrono::duration<double> duration = now - start;
    return duration.count();
}

void PureMS::showParameters(){
    // cout<<"c ----------------||LinearLS devloped by Xindi Zhang||------------------"<<endl;
    cout<<"c ----------------||LinearLS For Pure MaxSAT||------------------"<<endl;
    cout<<"c build and initialize used: "<<b_time<<" s"<<endl;
    cout<<"c threshold = 0.5 * nVars      p_scale = "<<p_scale<<"   seed = "<<seed<<endl;
    cout<<"c binaryPureHardClause = "<<binarySearch<<"    weighted = "<<weightedSearch<<endl;
    cout<<"c cc_tabu_apply per = "<<cc_tabu_no_impr<<"    increamental upbound Mod = "<<bound_mod<<endl;
    cout<<"c BMS pick nums = "<<try_num<<"     reset pick clause nums = "<<try_pick<<endl;
    cout<<"c ====================================================================="<<endl;
}

bool PureMS::varify(){
    for(int i=0;i<nHClauses;++i){
        bool sat = false;
        for(int p=0;p<c_lits_hard_size[i];++p){
            int j = c_lits_hard[i][p];
            if(b_soln[j] == 1){
                sat = true;
                break;
            }
        }if(!sat) return false;
    }
    long sum = 0;
    for(int i=1;i<=nVars;++i){
        if(b_soln[i]==1) sum += vweight[i];
    }
    if(sum == b_cost + unit_fixed_weight)
        return true;
    else
        return false; 
}

inline void PureMS::setSeed(int s){seed = s;}
inline void PureMS::setBoundMod(int bm){bound_mod = bm;}
inline void PureMS::setCCTabu(int ccb){cc_tabu_no_impr = ccb;}
inline void PureMS::setCutoff(int cutoff){cutoff_time = cutoff;}
inline void PureMS::setVerb(int v){verb = v;}
int main(int argc, char** argv){
    PureMS pMS;
    // ios::sync_with_stdio(false);

    if(argc<5) {
        cout<<"c use './purems <ins> <seed> <cutoff_time> <verbosity>' "<<endl;
        cout<<"c verbosity : 0, only print best solution"<<endl;
        cout<<"c           : 1, print best solution and best assignment"<<endl;
        cout<<"c           : 2, all information in the process and parameters"<<endl;
        exit(0); }
    string input_file(argv[1]);
    if(!pMS.build(input_file)) cout<<"build error\n";
    
    pMS.setSeed(stoi(string(argv[2])));
    pMS.setCutoff(stoi(string(argv[3])));
    pMS.setVerb(stoi(string(argv[4])));
    if(stoi(string(argv[4]))==2) 
        pMS.showParameters();

    bool build_res;

#ifdef RANDINIT
    build_res = pMS.initSoln_rand();
#else
    build_res = pMS.initSoln_heap();
#endif

    if(!build_res) cout<<"c build error"<<endl;

    bool res;
#ifdef BINARY
    res = pMS.doLS();
#else
    res = pMS.doLS_unbinary_weighted();
#endif
    if(res){
        pMS.showSoln(false);
    }else{
        cout<<"c There are something wrong with the local search process."<<endl;
    }
    pMS.freeMemory();
    return 0;
}
